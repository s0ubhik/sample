from PIL import Image, ImageOps
import sys
import os.path
import numpy as np

ncol   ="\033[0m"
bold   ="\033[1m"
dim    ="\033[2m"
uline  ="\033[4m"
reverse="\033[7m"
red    ="\033[31m"
green  ="\033[32m"
yellow ="\033[33m"
blue   ="\033[34m"
purple ="\033[35m"
cyan   ="\033[36m"
white  ="\033[37m"

n = len(sys.argv)
if n > 2:
	infile = sys.argv[1]
	format_ = sys.argv[2]

if n > 3: outfile = sys.argv[3]
else:
	outfile = os.path.basename(infile).split(".")[0] + "." + format_.lower()

if not os.path.exists(infile):
	print(f"{infile}: No such file")
	exit()

pixels = [[0]*128 for i in range(64)]
file = open(infile, "rb")
x = 0
y = 0

while (byte := file.read(1)):
	byte_s = "{:08b}".format(int(byte.hex(),16))
	for bit in byte_s:
		pixel = 255 if bit == "0" else 0
		pixels[y][x] = pixel
		x += 1
		if x > 127:
			x = 0
			y += 1

array = np.array(pixels, dtype=np.uint8)
new_image = Image.fromarray(array)
new_image.save(outfile, format=format_)
print(f"{bold}{green}{outfile}: Saved{ncol}")

