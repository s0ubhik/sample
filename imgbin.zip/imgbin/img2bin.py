from PIL import Image, ImageOps
import sys
import os.path

ncol   ="\033[0m"
bold   ="\033[1m"
dim    ="\033[2m"
uline  ="\033[4m"
reverse="\033[7m"
red    ="\033[31m"
green  ="\033[32m"
yellow ="\033[33m"
blue   ="\033[34m"
purple ="\033[35m"
cyan   ="\033[36m"
white  ="\033[37m"

n = len(sys.argv)
if n > 1: infile = sys.argv[1]
if n > 2: outfile = sys.argv[2]
else: outfile = os.path.basename(infile).split(".")[0] + ".bin"

if not os.path.exists(infile):
	print(f"{infile}: No such file")
	exit()


try: img_o = Image.open(infile)
except Exception:
    print(f"{infile}: Invalid image")
    exit()

print(f"File: {infile}")
print("Format:",img_o.format, "Mode:", img_o.mode)
print(f"Size: {img_o.width} x {img_o.height}")

img = img_o.resize((128, 64))

img =  ImageOps.grayscale(img)
c = 0
file = open(outfile, "wb+")
for y in range(img.height):
	byte_s = ""
	for x in range(img.width):
		if img.getpixel((x,y)) < 127: byte_s += "1" 
		else: byte_s += "0"
		if len(byte_s) >= 8: 
			byte = bytes(int(byte_s[i : i + 8], 2) for i in range(0, len(byte_s), 8))
			file.write(byte)
			byte_s = ""
			c += 1

file.close()

print(f"{bold}{green}{outfile}: Wrote {c} bytes{ncol}")



